package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;

import com.example.model.Employee;
import com.example.service.EmployeeService;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.*;
//import org.springframework.web.bind.annotation.*;



@SpringBootApplication
@EnableCaching
public class SpringBootRestStarter 
{

	@RequestMapping("/")
	@ResponseBody
	String home() 
	{
		return "Hello World!";
	}

	@Autowired
	private EmployeeService employeeService;

	
	@Cacheable(value="cachedEmployees")
	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public List<Employee> getEmployees() 
	{
		return employeeService.getAllEmployees();
	}

	@RequestMapping(value = "/employee/{id}", method = RequestMethod.GET)
	public Employee getEmployee(@PathVariable("id") long id) 
	{
		return employeeService.getEmployeeById(id);
	}
	
	@CachePut(value="cachedEmployees")
	@RequestMapping(value="/add",method = RequestMethod.GET)
    public void addEmployee(
    		@RequestParam(value = "employeeName", required = false) String employeeName,
    		@RequestParam(value = "employeeId", required = false,defaultValue = "unknown") String employeeId,
    		@RequestParam(value = "active", required = false,defaultValue = "false") boolean employeeActive
    						)
	{
    	Employee employee = new Employee(employeeId,employeeName,employeeActive);
    	employeeService.save(employee);
    }

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringBootRestStarter.class, args);
	}
}


