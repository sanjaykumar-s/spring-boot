package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.model.Employee;

@Repository("employeeRepository")
public interface EmployeeRepository extends JpaRepository<Employee,Long>
{

	List<Employee> findByName(String name);
	Employee findById(Long id);
	
}


/*
   
Notes

CrudRepository is part of Spring Data Commons project and declared under the package org.springframework.data.repository.  
JpaRepository is part of store specific implementation and declared under the package org.springframework.data.jpa.repository.
  
CrudeRepository extends from Repository interface. 
PagingAndSortingRepository extends from the CrudeRepository.
JpaRepository extends from PagingAndSortingRepository,

JpaRepository returns List type of entities whereas CrudRepository returns Iterable type of entities.

Not to use the store specific base interfaces as they expose the underlying persistence 
technology and tighten the coupling between them and the repository. 
It is always good idea to choose any of the generic base interfaces like CrudRepository or PagingAndSortungRepository.

@RepositoryRestResource can be used to create DATA Api's automatically,
without having need to implement them. Spring Boot will implement them at runtime.

import org.springframework.data.rest.core.annotation.RepositoryRestResource;
 
@RepositoryRestResource
public interface PersonRepository extends CrudRepository<Person, Long> {
 
}

*/